package com.restaurantdelivery.enums;

public enum VehicleType {

	BIKE,
	SCOOTER
}
