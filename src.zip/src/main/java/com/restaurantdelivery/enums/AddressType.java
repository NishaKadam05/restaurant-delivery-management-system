package com.restaurantdelivery.enums;

public enum AddressType {

	HOME,
	WORK,
	OTHER
}
