package com.restaurantdelivery.enums;

public enum DeliveryStatus {
	ASSIGNED,
	ACCEPTED,
	PICKED_UP,
	DELIVERED,
	REJECTED, 
	CANCELLED
}
