package com.restaurantdelivery.enums;

public enum OrderType {

	DELIVERY,
	SELF_PICKUP
}
