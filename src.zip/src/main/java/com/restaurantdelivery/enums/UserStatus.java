package com.restaurantdelivery.enums;

public enum UserStatus {

	ACTIVE,
	INACTIVE,
	SUSPENDED
}
