package com.restaurantdelivery.enums;

public enum DiscountType {

	PERCENTAGE,
	FIXED_AMOUNT
}
