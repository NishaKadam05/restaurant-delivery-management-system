package com.restaurantdelivery.enums;

public enum ReviewType {

	FOOD,
	DELIVERY,
	RESTAURANT
}
