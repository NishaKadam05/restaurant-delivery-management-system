package com.restaurantdelivery.enums;

public enum UserRole {

	ADMIN,
	CUSTOMER,
	RESTAURANT_STAFF,
	DELIVERY_PARTNER
}
