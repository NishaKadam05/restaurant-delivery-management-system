package com.restaurantdelivery.enums;

public enum PaymentMethod {

	CARD,
	CASH_ON_DELIVERY,
	UPI
}
