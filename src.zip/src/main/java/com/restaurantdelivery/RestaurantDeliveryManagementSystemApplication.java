package com.restaurantdelivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantDeliveryManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantDeliveryManagementSystemApplication.class, args);
	}

}
